-- Database Dump untuk Eksotis Jogja (MySQL / MariaDB)
-- Cocok untuk phpMyAdmin XAMPP
-- Dibuat pada: 2026-11-16 18:14:39

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- --------------------------------------------------------
-- Struktur tabel `users`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pelanggan',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Struktur tabel `motors`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `motors`;
CREATE TABLE `motors` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `daily` int unsigned NOT NULL,
  `weekend` int unsigned NOT NULL,
  `weekly` int unsigned NOT NULL,
  `monthly` int unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Struktur tabel `units`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `units`;
CREATE TABLE `units` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `motor_id` bigint unsigned NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `units_code_unique` (`code`),
  KEY `units_motor_id_foreign` (`motor_id`),
  CONSTRAINT `units_motor_id_foreign` FOREIGN KEY (`motor_id`) REFERENCES `motors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Struktur tabel `bookings`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `bookings`;
CREATE TABLE `bookings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `unit_id` bigint unsigned NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identity` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `province` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pickup` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rent` int unsigned NOT NULL,
  `fee` int unsigned NOT NULL DEFAULT '0',
  `distance` decimal(5,2) DEFAULT NULL,
  `paid` int unsigned NOT NULL DEFAULT '0',
  `submitted` int unsigned NOT NULL DEFAULT '0',
  `method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `handed_at` datetime DEFAULT NULL,
  `returned_at` datetime DEFAULT NULL,
  `condition` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `request_key` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bookings_code_unique` (`code`),
  UNIQUE KEY `bookings_user_id_request_key_unique` (`user_id`,`request_key`),
  KEY `bookings_unit_id_start_end_index` (`unit_id`,`start`,`end`),
  KEY `bookings_user_id_foreign` (`user_id`),
  CONSTRAINT `bookings_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Struktur tabel `messages`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint unsigned DEFAULT NULL,
  `sender_id` bigint unsigned NOT NULL,
  `channel` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'operasional',
  `body` text COLLATE utf8mb4_unicode_ci,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `messages_customer_id_foreign` (`customer_id`),
  KEY `messages_sender_id_foreign` (`sender_id`),
  CONSTRAINT `messages_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `messages_sender_id_foreign` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Tabel sistem Laravel
-- --------------------------------------------------------
DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `cache`;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `cache_locks`;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk tabel `users`
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `role`) VALUES
(1, 'Admin', 'admin@gmail.com', NULL, '$2y$12$Ed7Sw5isQ9l/gg3pcctp4.GiACKisEYyIKlVSOJ4SfuwcOGQA6nES', NULL, NULL, '2026-11-16 23:46:14', 'admin'),
(2, 'Petugas', 'petugas@gmail.com', NULL, '$2y$12$tALdIrXIiuqFRCXy1hQlLeCiv1FGwe3eQBXnf3ZDTVvroESVUTmcS', NULL, NULL, '2026-11-16 23:45:23', 'petugas'),
(3, 'Pelanggan', 'pelanggan@gmail.com', NULL, '$2y$12$3fk/wCjv/.CPvNCkMOhSlO0i.s/lRinrE15fdEEc6s7cdlSgrB5O6', NULL, NULL, '2026-11-16 23:47:33', 'pelanggan'),
(4, 'sugeng', 'sugeng@gmail.com', NULL, '$2y$12$xYvvlpF3Nah5mjgwiF1DMe59320n6nPG.FcZRn.sefnQD2UfjwDPy', NULL, '2026-11-17 00:00:31', '2026-11-17 00:00:31', 'pelanggan');

-- Data untuk tabel `motors`
INSERT INTO `motors` (`id`, `name`, `image`, `daily`, `weekend`, `weekly`, `monthly`) VALUES
(1, 'Honda Beat FI', 'beat', 80000, 85000, 510000, 2200000),
(2, 'Honda Vario 125', 'vario', 100000, 110000, 650000, 2800000),
(3, 'Yamaha Mio GT', 'mio', 80000, 85000, 510000, 2200000),
(4, 'Honda Beat Street', 'street', 85000, 90000, 545000, 2350000),
(5, 'Yamaha NMAX', 'nmax', 135000, 145000, 895000, 3850000),
(6, 'Yamaha Fazzio', 'fazzio', 95000, 105000, 615000, 2650000);

-- Data untuk tabel `units`
INSERT INTO `units` (`id`, `motor_id`, `code`) VALUES
(1, 1, 'BEAT-01'),
(2, 1, 'BEAT-02'),
(3, 1, 'BEAT-03'),
(4, 1, 'BEAT-04'),
(5, 1, 'BEAT-05'),
(6, 1, 'BEAT-06'),
(7, 1, 'BEAT-07'),
(8, 1, 'BEAT-08'),
(9, 1, 'BEAT-09'),
(10, 1, 'BEAT-10'),
(11, 1, 'BEAT-11'),
(12, 1, 'BEAT-12'),
(13, 1, 'BEAT-13'),
(14, 1, 'BEAT-14'),
(15, 1, 'BEAT-15'),
(16, 1, 'BEAT-16'),
(17, 2, 'VARIO-01'),
(18, 2, 'VARIO-02'),
(19, 2, 'VARIO-03'),
(20, 2, 'VARIO-04'),
(21, 2, 'VARIO-05'),
(22, 2, 'VARIO-06'),
(23, 2, 'VARIO-07'),
(24, 3, 'MIO-01'),
(25, 4, 'STREET-01'),
(26, 4, 'STREET-02'),
(27, 5, 'NMAX-01'),
(28, 5, 'NMAX-02'),
(29, 5, 'NMAX-03'),
(30, 5, 'NMAX-04'),
(31, 5, 'NMAX-05'),
(32, 5, 'NMAX-06'),
(33, 6, 'FAZZIO-01'),
(34, 6, 'FAZZIO-02'),
(35, 6, 'FAZZIO-03');

-- Data untuk tabel `bookings`
INSERT INTO `bookings` (`id`, `code`, `user_id`, `unit_id`, `start`, `end`, `name`, `phone`, `identity`, `province`, `pickup`, `address`, `status`, `rent`, `fee`, `distance`, `paid`, `submitted`, `method`, `reference`, `handed_at`, `returned_at`, `condition`, `created_at`, `updated_at`, `request_key`) VALUES
(1, 'EJ-P7VYOEIXI', 3, 1, '2026-11-12 09:00:00', '2026-11-13 09:00:00', 'IYA', '0213445689', 'eyJpdiI6IkdjaVFKL2MzQ3prSVRTcHA3T0ZreEE9PSIsInZhbHVlIjoiQVdTWGhVNUN3dTM0bTlpTytMSE9abm5DQVRBQjFuUEpBd2tiMjA4Z0ZmND0iLCJtYWMiOiI5NDJlOTk0M2MwNmY5ZTU3NTBlZmNhYmNhYmQ1Nzc2NGFhMjI2MTZmNzQxMTYxOTQ3ZGJiYWYyMDJiYmE5MzA1IiwidGFnIjoiIn0=', 'Jawa Tengah', 'cod', 'DAERAH INI HOTEL INI', 'periksa', 80000, '0', '0', '0', 50000, 'Transfer', 1164491, NULL, NULL, NULL, '2026-11-11 01:09:24', '2026-11-16 23:47:51', '10ceb5ae-42ae-4d67-91b0-908ec8489eec');

-- Data untuk tabel `messages`
INSERT INTO `messages` (`id`, `customer_id`, `sender_id`, `body`, `latitude`, `longitude`, `created_at`, `updated_at`, `channel`) VALUES
(1, 3, 3, 'nama saya', -7.7513932, 110.353475, '2026-11-11 01:06:23', '2026-11-11 01:06:23', 'operasional'),
(2, 3, 1, 'okey', NULL, NULL, '2026-11-11 01:07:57', '2026-11-11 01:07:57', 'operasional'),
(3, 3, 3, NULL, -7.7513705, 110.3535129, '2026-11-11 01:09:33', '2026-11-11 01:09:33', 'operasional'),
(4, 3, 3, 'hallo min', NULL, NULL, '2026-11-16 23:57:27', '2026-11-16 23:57:27', 'cs'),
(5, 3, 1, 'ss', NULL, NULL, '2026-11-16 23:58:08', '2026-11-16 23:58:08', 'cs'),
(6, 3, 1, 'okey', NULL, NULL, '2026-11-16 23:58:21', '2026-11-16 23:58:21', 'cs'),
(7, NULL, 1, 'aman to', NULL, NULL, '2026-11-16 23:58:58', '2026-11-16 23:58:58', 'internal');

-- Data untuk tabel `migrations`
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2026_01_01_000000_create_rental_tables', 1),
(5, '2026_11_10_000001_add_booking_request_key', 1),
(6, '2026_11_16_235258_update_messages_table_for_channels', 2);

SET FOREIGN_KEY_CHECKS=1;
COMMIT;
