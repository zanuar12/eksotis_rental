@extends('layout')
@section('body')
<div class="page narrow">
    <p class="eyebrow"><i></i> {{ auth()->user()->role === 'admin' ? 'ADMIN / MONITORING' : 'PETUGAS / OPERASIONAL' }}</p>
    <h1 class="pageTitle">Chat Operasional Antar Pesanan.</h1>

    <div class="inline subnav" style="margin-bottom:20px;">
        <span class="small" style="background:#075747; color:#fff;">🛵 Chat Pelanggan (Antar Unit)</span>
        <a class="small secondary" href="/chat-internal">🔒 Chat Internal Tim (Admin & Petugas)</a>
    </div>

    <div class="panel stack">
        <p class="muted">
            {{ auth()->user()->role === 'admin' 
                ? 'Pilih pelanggan untuk memantau atau bergabung dalam percakapan pengantaran unit antara petugas dan pelanggan:' 
                : 'Pilih pelanggan untuk koordinasi pengantaran motor, janjian COD, atau konfirmasi penjemputan:' }}
        </p>
        <div class="stack">
            @forelse($customers as $c)
                <div class="row" style="padding:12px; border:1px solid #e1ebe2; border-radius:8px; align-items:center;">
                    <div>
                        <strong>{{ $c->name }}</strong>
                        <div class="muted">{{ $c->email }}</div>
                    </div>
                    <a class="small" href="/chat/{{ $c->id }}">Buka Chat →</a>
                </div>
            @empty
                <p>Belum ada pelanggan terdaftar.</p>
            @endforelse
        </div>
    </div>
</div>
@endsection
