@extends('layout')

@section('body')
<div class="page narrow">
    <a class="back" href="/#armada">← Kembali ke armada</a>
    <p class="eyebrow"><i></i> BOOKING MOTOR</p>
    <h1 class="pageTitle">Pesan {{ $m->name }}.</h1>

    <div class="panel">
        <b>{{ $start->format('d/m/Y H:i') }} – {{ $end->format('d/m/Y H:i') }} WIB</b>
        <div>Biaya sewa <strong>{{ \App\Services\Rental::rp(\App\Services\Rental::price($m, $start, $end)) }}</strong></div>
    </div>

    <form method="post" action="/booking/{{ $m->id }}" class="panel stack">
        @csrf
        <input type="hidden" name="request_key" value="{{ old('request_key', (string) \Illuminate\Support\Str::uuid()) }}">
        <input type="hidden" name="start" value="{{ $start->format('Y-m-d\TH:i') }}">
        <input type="hidden" name="end" value="{{ $end->format('Y-m-d\TH:i') }}">

        <h3>Identitas pemesan</h3>

        <div class="two">
            <label>
                Nama sesuai KTP
                <input required name="name" value="{{ old('name', auth()->user()->name) }}">
            </label>
            <label>
                Nomor HP
                <input required name="phone" type="tel" value="{{ old('phone') }}">
            </label>
        </div>

        <label>
            NIK (16 digit)
            <input name="nik" inputmode="numeric" pattern="[0-9]{16}" maxlength="16" autocomplete="off" required>
        </label>

        <label>
            Provinsi domisili yang tertulis pada KTP
            <select required name="province">
                <option value="">Pilih provinsi</option>
                @foreach (config('provinces') as $p)
                    <option @selected(old('province') === $p)>{{ $p }}</option>
                @endforeach
            </select>
        </label>

        <h3>Pengambilan motor</h3>
        <label>
            Metode pengambilan
            <select id="pickup" name="pickup">
                <option value="rental">Ambil di rental Jombor</option>
                <option value="cod" @selected(old('pickup') === 'cod')>COD · antar ke lokasi</option>
            </select>
        </label>

        <p class="hint" id="rental">Ambil di Jl. Jombor Lor, Sinduadi, Mlati, Sleman sesuai waktu mulai sewa.</p>

        <label id="alamat">
            Alamat pengantaran dan patokan
            <textarea name="address">{{ old('address') }}</textarea>
            <span class="hint">Titik Google Maps dapat dikirim lewat chat setelah booking.</span>
        </label>

        <button>Simpan booking →</button>
    </form>
</div>

<script>
    const pickup = document.querySelector('#pickup');
    const alamat = document.querySelector('#alamat');
    const rental = document.querySelector('#rental');

    function togglePickup() {
        const isCod = pickup.value === 'cod';
        alamat.style.display = isCod ? 'grid' : 'none';
        alamat.querySelector('textarea').required = isCod;
        rental.hidden = isCod;
    }

    pickup.onchange = togglePickup;
    togglePickup();
</script>
@endsection
