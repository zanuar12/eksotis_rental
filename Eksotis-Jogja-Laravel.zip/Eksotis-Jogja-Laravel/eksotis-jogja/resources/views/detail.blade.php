@extends('layout')

@section('body')
@php
    $role = auth()->user()->role;
    $owner = $role === 'pelanggan';
    $admin = $role === 'admin';
    $staff = !$owner;
    $rp = [\App\Services\Rental::class, 'rp'];
    $total = $b->rent + $b->fee;
@endphp

<div class="page narrow">
    <a href="/pesanan" class="back">← Daftar pesanan</a>
    <p class="eyebrow"><i></i> {{ $b->code }}</p>
    <h1 class="pageTitle">{{ $b->motor }}.</h1>

    <div class="panel">
        <span class="status">{{ \App\Services\Rental::STATUS[$b->status] }}</span>

        <dl class="facts">
            <dt>Unit</dt>
            <dd>{{ $b->unit }}</dd>

            <dt>Pelanggan</dt>
            <dd>{{ $b->name }} · {{ $b->phone }}</dd>

            <dt>Domisili KTP</dt>
            <dd>{{ $b->province }}</dd>

            <dt>Jadwal WIB</dt>
            <dd>{{ $b->start }} s.d. {{ $b->end }}</dd>

            <dt>Pengambilan</dt>
            <dd>{{ $b->pickup === 'cod' ? 'Antar ke ' . $b->address : 'Ambil di Jl. Jombor Lor, Sinduadi, Mlati, Sleman' }}</dd>

            <dt>Biaya sewa</dt>
            <dd>{{ $rp($b->rent) }}</dd>

            <dt>Ongkir</dt>
            <dd>{{ $b->status === 'cod' ? 'Menunggu pemeriksaan admin' : $rp($b->fee) }}</dd>

            <dt>Total sementara</dt>
            <dd><b>{{ $rp($total) }}</b></dd>

            <dt>Sudah dibayar</dt>
            <dd>{{ $rp($b->paid) }}</dd>

            <dt>Sisa tagihan</dt>
            <dd>{{ $rp($total - $b->paid) }}</dd>

            @if ($b->reference)
                <dt>Referensi bayar</dt>
                <dd>{{ $b->method }} · {{ $b->reference }} · {{ $rp($b->submitted) }}</dd>
            @endif

            @if ($b->condition)
                <dt>Kondisi kembali</dt>
                <dd>{{ $b->condition }}</dd>
            @endif
        </dl>

        <div class="inline">
            <a class="small secondary" href="/chat/{{ $b->user_id }}">
                {{ $owner ? '🛵 Chat Petugas / Bagikan Lokasi' : ($admin ? '👁️ Pantau Chat Petugas & Pelanggan' : '🛵 Chat Pelanggan') }}
            </a>
            @if (in_array($b->status, ['siap', 'jalan', 'kembali', 'selesai']))
                <a class="small" href="/pesanan/{{ $b->id }}/invoice">Lihat invoice ↗</a>
            @endif
        </div>
    </div>

    @if ($b->status === 'cod' && $owner)
        <p class="notice">Alamat sedang diperiksa. Kirim titik pengantaran lewat chat agar admin dapat menentukan ongkir.</p>
    @endif

    @if ($b->status === 'alternatif')
        <p class="alert">Lokasi di luar jangkauan COD. Pelanggan dapat memilih ambil di rental atau membatalkan booking.</p>
    @endif

    <form class="stack" method="post">
        @csrf

        @if ($admin && $b->status === 'cod')
            <div class="panel stack">
                <h3>Pemeriksaan jangkauan COD</h3>
                <p>Periksa rute dari rental menuju titik pelanggan di Google Maps.</p>
                <label>
                    Jarak rute (km)
                    <input type="number" name="distance" min="0" max="999" step=".01" required>
                </label>
                <label>
                    Ongkir (rupiah)
                    <input type="number" name="fee" min="0" max="30000" value="0">
                </label>
                <span class="hint">≤2 km gratis · &gt;2–9 km Rp15.000–Rp30.000 · &gt;9 km tidak dilayani.</span>
                <button name="action" value="review">Simpan hasil pemeriksaan</button>
            </div>
        @endif

        @if ($owner && $b->status === 'alternatif')
            <button name="action" value="pickup">Ganti ke ambil di rental</button>
        @endif

        @if ($owner && $b->status === 'bayar')
            <div class="panel stack">
                <h3>Konfirmasi pembayaran</h3>
                <label>
                    Jumlah pembayaran
                    <select name="plan">
                        <option value="dp">DP · Rp50.000</option>
                        <option value="full">Lunas · {{ $rp($total) }}</option>
                    </select>
                </label>
                <label>
                    Metode
                    <select name="method">
                        <option>Transfer</option>
                        <option>QRIS</option>
                    </select>
                </label>
                <label>
                    Nomor referensi transaksi
                    <input required name="reference" maxlength="100">
                </label>
                <button name="action" value="pay">Ajukan verifikasi</button>
            </div>
        @endif

        @if ($admin && $b->status === 'periksa')
            <div class="panel stack">
                <h3>Verifikasi pembayaran</h3>
                <p>Cocokkan referensi, metode, dan nominal {{ $rp($b->submitted) }} dengan catatan penerimaan.</p>
                <div class="inline">
                    <button name="action" value="verify">Pembayaran sesuai</button>
                    <button class="secondary" name="action" value="reject">Minta kirim ulang</button>
                </div>
            </div>
        @endif

        @if ($staff && $b->status === 'siap')
            <div class="panel stack">
                <h3>Serah terima unit</h3>
                <label class="check">
                    <input name="confirm" value="1" type="checkbox" required>
                    Identitas asli diperiksa, sisa {{ $rp($total - $b->paid) }} diterima, dan motor sudah diserahkan.
                </label>
                <button name="action" value="handover">Mulai penyewaan</button>
            </div>
        @endif

        @if ($owner && $b->status === 'jalan')
            <button name="action" value="return">Ajukan pengembalian</button>
        @endif

        @if ($staff && in_array($b->status, ['jalan', 'kembali']))
            <div class="panel stack">
                <h3>Pemeriksaan pengembalian</h3>
                <label>
                    Kondisi akhir dan catatan penyelesaian
                    <textarea name="condition" required></textarea>
                </label>
                <button name="action" value="close">Terima motor & selesaikan sewa</button>
            </div>
        @endif

        @if ($owner && in_array($b->status, ['cod', 'alternatif', 'bayar']))
            <button class="secondary" formnovalidate name="action" value="cancel" onclick="return confirm('Batalkan booking ini?')">
                Batalkan booking
            </button>
        @endif
    </form>
</div>
@endsection
