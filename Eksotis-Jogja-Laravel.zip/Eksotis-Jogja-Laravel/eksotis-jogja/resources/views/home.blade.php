@extends('layout')
@section('body')
<section class="hero">
    <div class="heroText">
        <p class="eyebrow"><i></i> RENTAL MOTOR WISATA · YOGYAKARTA</p>
        <h1>Jelajah Jogja<br><em>naik motor.</em></h1>
        <p class="intro">Mulai dari Jombor, singgahi sudut Jogja favoritmu. Nikmati kemudahan sewa motor matic terawat, helm bersih, dan unit diantar langsung ke stasiun atau hotel.</p>

        <div class="hero-specs">
            <div class="spec-item">
                <span class="spec-num">35 UNIT</span>
                <span class="spec-label">Armada Prima</span>
            </div>
            <div class="spec-sep">/</div>
            <div class="spec-item">
                <span class="spec-num">COD GRATIS</span>
                <span class="spec-label">Radius ≤2 Km</span>
            </div>
            <div class="spec-sep">/</div>
            <div class="spec-item">
                <span class="spec-num">LENGKAP</span>
                <span class="spec-label">2 Helm & Jas Hujan</span>
            </div>
        </div>

        <div class="inline">
            <a class="btn" href="#armada">Pilih motor <span>↗</span></a>
            <a class="small secondary" href="/syarat">Syarat Sewa →</a>
        </div>
    </div>

    <div class="poster" id="hero-poster">
        <div class="poster-inner">
            <div class="poster-track" id="poster-track">
                @php
                    $palettes = [
                        ['bg' => '#c2ddcb', 'sun' => '#eeab70'],
                        ['bg' => '#dfd6c6', 'sun' => '#df8e5a'],
                        ['bg' => '#d4e3e6', 'sun' => '#f2ad74'],
                        ['bg' => '#e8ded2', 'sun' => '#e89963'],
                        ['bg' => '#d2ded8', 'sun' => '#f0a266'],
                        ['bg' => '#e4ded9', 'sun' => '#e69a5c'],
                    ];
                @endphp
                @foreach($motors as $index => $m)
                    @php
                        $palette = $palettes[$index % count($palettes)];
                        $shortName = \Illuminate\Support\Str::after($m->name, ' ');
                    @endphp
                    <div class="poster-slide {{ $index === 0 ? 'active' : '' }}" 
                         style="background: {{ $palette['bg'] }};"
                         data-color="{{ $palette['bg'] }}" 
                         data-sun="{{ $palette['sun'] }}">
                        <div class="posterTop">
                            <b>EKSOTIS / JOGJA</b>
                            <span>KOLEKSI {{ strtoupper($m->brand) }}</span>
                        </div>
                        <div class="sun" style="background: {{ $palette['sun'] }};"></div>
                        <span class="posterName">{{ $shortName }}</span>
                        <div class="bike-stage">
                            <img class="floating-bike" src="/img/{{ $m->image }}.png" alt="{{ $m->name }}">
                            <div class="bike-shadow"></div>
                        </div>
                        <div class="posterBottom">
                            <strong>{{ $m->name }}</strong>
                            <span class="slide-indicator">{{ sprintf('%02d', $index + 1) }} / {{ sprintf('%02d', count($motors)) }}</span>
                            <span>Mulai {{ \App\Services\Rental::rp($m->daily) }} / hari</span>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>

        <button type="button" class="poster-nav prev" id="slide-prev" aria-label="Sebelumnya">‹</button>
        <button type="button" class="poster-nav next" id="slide-next" aria-label="Berikutnya">›</button>
    </div>
</section>

<section id="armada">
    <p class="eyebrow"><i></i> ARMADA KAMI</p>
    <h2>Motor untuk perjalananmu<span class="dot">.</span></h2>
    <form class="filter" action="/#armada">
        <label>Mulai sewa · WIB<input name="start" type="datetime-local" value="{{$start->format('Y-m-d\TH:i')}}" required></label>
        <label>Pengembalian · WIB<input name="end" type="datetime-local" value="{{$end->format('Y-m-d\TH:i')}}" required></label>
        <button>Cek ketersediaan →</button>
    </form>
    <p class="muted">Ketersediaan untuk {{ $start->format('d/m/Y H:i') }} – {{ $end->format('d/m/Y H:i') }} WIB. Harga periode sudah termasuk tarif akhir pekan atau paket.</p>
    @include('catalog-filter')
    <div class="cards">
        @foreach($motors as $m)
            <article class="card" data-motor-id="{{ $m->id }}">
                <div class="photo">
                    <span class="pill">{{ $m->free ? $m->free.' unit tersedia' : 'Penuh' }}</span>
                    <img loading="lazy" src="/img/{{$m->image}}.png" alt="Ilustrasi {{$m->name}}">
                </div>
                <div class="cardBody">
                    <small>{{strtoupper($m->brand)}} / MATIC</small>
                    <h3>{{$m->name}}</h3>
                    <p>Mulai <b>{{\App\Services\Rental::rp($m->daily)}}</b> / hari</p>
                    <div class="cardEnd">
                        <div>
                            <small>Total periode</small>
                            <strong>{{\App\Services\Rental::rp($m->quote)}}</strong>
                        </div>
                        @if($m->free)
                            <a class="small" href="/booking/{{$m->id}}?{{http_build_query(['start'=>$start->format('Y-m-d\TH:i'),'end'=>$end->format('Y-m-d\TH:i')])}}">Pesan ↗</a>
                        @else
                            <span>Pilih jadwal lain</span>
                        @endif
                    </div>
                </div>
            </article>
        @endforeach
    </div>
    <details>
        <summary>Daftar tarif harian, akhir pekan, mingguan dan bulanan</summary>
        <div class="tablewrap">
            <table>
                <tr>
                    <th>Motor</th>
                    <th>Sen–Jum</th>
                    <th>Sab–Min</th>
                    <th>7 hari</th>
                    <th>30 hari</th>
                </tr>
                @foreach($motors as $m)
                    <tr>
                        <td>{{$m->name}}</td>
                        @foreach(['daily','weekend','weekly','monthly'] as $k)
                            <td>{{\App\Services\Rental::rp($m->$k)}}</td>
                        @endforeach
                    </tr>
                @endforeach
            </table>
        </div>
    </details>
</section>
@endsection

@push('scripts')
<script src="/hero-anim.js" defer></script>
@endpush
