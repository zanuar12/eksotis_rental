<details id="semantic-search">
    <summary>Pencarian</summary>
    <form id="catalog-search" class="catalog-search">
        <div class="field">
            <label for="catalog-brand">Merek</label>
            <select name="brand" id="catalog-brand">
                <option value="">Semua merek</option>
                @foreach($motors->pluck('brand')->unique()->sort() as $brand)
                    <option value="{{ $brand }}">{{ $brand }}</option>
                @endforeach
            </select>
        </div>
        <label class="field">Bujet sewa untuk periode ini (Rp)
            <input type="number" name="budget" min="0" max="999999999999" step="1" placeholder="Tanpa batas">
        </label>
        <label class="catalog-check"><input name="available" type="checkbox"> Hanya yang tersedia</label>
        <div class="inline">
            <button type="submit">Cari motor</button>
            <button type="reset" class="secondary">Atur ulang</button>
        </div>
    </form>
    <noscript>Aktifkan JavaScript untuk menggunakan pencarian semantik. Semua motor untuk jadwal ini tercantum di bawah.</noscript>
</details>
<p id="catalog-result" role="status" aria-live="polite"></p>
<script id="catalog-rdf" type="application/ld+json">@json($catalogGraph)</script>
@push('scripts')
    <script type="module" src="/semantik/pencarian.js"></script>
@endpush
