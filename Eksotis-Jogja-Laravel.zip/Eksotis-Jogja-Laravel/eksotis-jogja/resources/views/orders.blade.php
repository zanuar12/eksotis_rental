@extends('layout')
@section('body')
<div class="page"><p class="eyebrow"><i></i> {{strtoupper(auth()->user()->role)}}</p><h1 class="pageTitle">{{auth()->user()->role==='pelanggan'?'Riwayat pesanan':'Dashboard penyewaan'}}.</h1>
@if(auth()->user()->role==='admin')
<div class="inline subnav">
    <a class="small" href="/operasional">Data armada & laporan</a>
    <a class="small secondary" href="/chat">🛵 Monitoring Chat Pelanggan</a>
    <a class="small secondary" href="/chat-internal">🔒 Chat Internal Tim</a>
</div>
@elseif(auth()->user()->role==='petugas')
<div class="inline subnav">
    <a class="small secondary" href="/chat">🛵 Chat Pelanggan (Antar Unit)</a>
    <a class="small secondary" href="/chat-internal">🔒 Chat Internal Tim</a>
</div>
@endif
<form class="filter"><label>Kode booking<input name="q" value="{{request('q')}}" placeholder="EJ-…"></label><label>Status<select name="status"><option value="">Semua status</option>@foreach(\App\Services\Rental::STATUS as $k=>$label)<option value="{{$k}}" @selected(request('status')===$k)>{{$label}}</option>@endforeach</select></label><button>Tampilkan</button></form>
<div class="panel tablewrap"><table><thead><tr><th>Booking</th><th>Motor / unit</th><th>Mulai (WIB)</th><th>Status</th></tr></thead><tbody>@forelse($orders as $b)<tr><td><a class="orderlink" href="/pesanan/{{$b->id}}">{{$b->code}}</a><br>{{$b->name}}</td><td>{{$b->motor}}<br>{{$b->unit}}</td><td>{{$b->start}}</td><td><span class="status">{{\App\Services\Rental::STATUS[$b->status]}}</span></td></tr>@empty<tr><td colspan="4">Belum ada pesanan yang cocok.</td></tr>@endforelse</tbody></table><div class="inline">@if($orders->previousPageUrl())<a href="{{$orders->previousPageUrl()}}">← Sebelumnya</a>@endif @if($orders->nextPageUrl())<a href="{{$orders->nextPageUrl()}}">Berikutnya →</a>@endif</div></div></div>
@endsection
