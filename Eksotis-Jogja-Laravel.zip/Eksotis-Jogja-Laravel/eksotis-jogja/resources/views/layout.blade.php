<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title','Rental Motor') · Eksotis Jogja</title>
    <link rel="stylesheet" href="/style.css">
</head>
<body>
<header>
    <nav class="wrap">
        <a class="brand" href="/"><span class="mark">EJ</span>Eksotis<span class="light">Jogja</span></a>
        <div class="links">
            <a href="/#armada">Tarif sewa</a>
            <a href="/syarat">Syarat sewa</a>

            @auth
                @if(auth()->user()->role === 'pelanggan')
                    <a href="/chat">Chat Petugas (Antar Unit)</a>
                @elseif(auth()->user()->role === 'petugas')
                    <a href="/chat">Chat Pelanggan</a>
                    <a href="/chat-internal">Chat Internal</a>
                @elseif(auth()->user()->role === 'admin')
                    <a href="/chat">Monitoring Chat</a>
                    <a href="/chat-internal">Chat Internal</a>
                @endif
                <a href="/pesanan">Pesanan</a>
                <form method="post" action="/keluar">
                    @csrf
                    <button class="small">Keluar</button>
                </form>
            @else
                <a class="small" href="/login">Masuk ↗</a>
            @endauth
        </div>
    </nav>
</header>

<main class="wrap">
    @if($errors->any())
        <div role="alert" class="alert">
            @foreach($errors->all() as $error)
                <div>{{ $error }}</div>
            @endforeach
        </div>
    @endif
    @if(session('ok'))
        <div class="notice">{{ session('ok') }}</div>
    @endif
    @yield('body')
</main>

<footer>
    <div class="wrap">
        <div class="footer-grid">
            <div class="footer-col">
                <a class="brand" href="/" style="color:#ffffff; margin-bottom:12px; display:inline-flex;">
                    <span class="mark">EJ</span>Eksotis<span class="light">Jogja</span>
                </a>
                <p>Rental motor terpercaya di Yogyakarta sejak 2020. Solusi keliling Jogja tanpa ribet dengan armada matic terawat, fasilitas lengkap (2 helm SNI & jas hujan), serta layanan antar-jemput COD stasiun, terminal & hotel.</p>
                <div class="footer-badge-box">
                    <span>📍</span> Garasi: Jl. Jombor Lor, Sinduadi, Mlati, Sleman, DIY 55284
                </div>
            </div>

            <div class="footer-col">
                <h4>PILIHAN SEWA</h4>
                <ul>
                    <li><a href="/#armada">Sewa Harian (Mulai 80rb)</a></li>
                    <li><a href="/#armada">Paket Akhir Pekan</a></li>
                    <li><a href="/#armada">Paket Mingguan & Bulanan</a></li>
                    <li><a href="/syarat">Syarat & Dokumen Sewa</a></li>
                </ul>
            </div>

            <div class="footer-col">
                <h4>AREA LAYANAN</h4>
                <ul>
                    <li><a href="https://www.google.com/maps/search/?api=1&query=Eksotis+Jogja+Jombor+Lor+Sinduadi" target="_blank" rel="noopener">Ambil di Rental (Jombor)</a></li>
                    <li><a href="/syarat">Antar Stasiun Tugu (COD)</a></li>
                    <li><a href="/syarat">Antar Stasiun Lempuyangan</a></li>
                    <li><a href="/syarat">Antar Hotel & Penginapan</a></li>
                </ul>
            </div>

            <div class="footer-col">
                <h4>JAM OPERASIONAL</h4>
                <p><strong>06.00 – 22.00 WIB</strong><br><small style="color:#8fb39d;">Buka Setiap Hari (Senin–Minggu)</small></p>
                <p style="margin-top:10px;">Butuh bantuan sewa atau cek stok cepat? Hubungi CS kami melalui tombol chat di samping.</p>
                <a class="textlink" href="https://www.google.com/maps/search/?api=1&query=Eksotis+Jogja+Jombor+Lor+Sinduadi" target="_blank" rel="noopener" style="color:#f4a565;">Buka Rute di Google Maps ↗</a>
            </div>
        </div>

        <div class="footer-bottom">
            <div>© {{ date('Y') }} <strong>Eksotis Jogja</strong> — Sistem Informasi Penyewaan Motor Yogyakarta.</div>
            <div style="display:flex; gap:16px;">
                <a href="/syarat" style="color:inherit;">Syarat & Ketentuan</a>
                <span>·</span>
                <a href="/#armada" style="color:inherit;">Katalog Motor</a>
                <span>·</span>
                <span>DIY Yogyakarta</span>
            </div>
        </div>
    </div>
</footer>

<!-- Floating Circular CS Chat Button -->
<button id="cs-floating-btn" class="cs-floating-fab" type="button" aria-label="Customer Service">
    <span class="cs-fab-icon">🎧</span>
    <span class="cs-fab-ping"></span>
    <span class="cs-fab-tooltip">💬 Butuh bantuan? Chat CS</span>
</button>

<!-- Floating CS Chat Window -->
<div id="cs-chat-window" class="cs-chat-window" data-role="{{ auth()->check() ? auth()->user()->role : 'guest' }}" data-user-id="{{ auth()->id() }}">
    <div class="cs-header">
        <div>
            <h4>🎧 CS Eksotis Jogja</h4>
            <small>Layanan Pelanggan (Admin)</small>
        </div>
        <button id="cs-close-btn" class="cs-close-btn" type="button" aria-label="Tutup">✕</button>
    </div>

    @guest
        <div class="cs-guest-box">
            <p>Butuh bantuan seputar sewa motor atau informasi rental?</p>
            <p>Silakan masuk untuk memulai obrolan dengan Customer Service kami.</p>
            <a href="/login" class="small">Masuk / Login ↗</a>
        </div>
    @else
        @if(auth()->user()->role === 'petugas')
            <div class="cs-guest-box">
                <p><strong>Halo, Petugas!</strong></p>
                <p>Ruang CS ini dikhususkan untuk Pelanggan & Admin.</p>
                <p>Untuk koordinasi antar pesanan, silakan gunakan:</p>
                <div class="stack" style="gap:8px; margin-top:12px;">
                    <a href="/chat" class="small">🛵 Chat Pelanggan (Antar Unit)</a>
                    <a href="/chat-internal" class="small secondary">🔒 Chat Internal Tim</a>
                </div>
            </div>
        @else
            @if(auth()->user()->role === 'admin')
                <div style="padding: 8px 12px; background: #fdfdfd; border-bottom: 1px solid #ccd8cd;">
                    <select id="cs-select-customer" class="cs-customer-select">
                        <option value="">-- Memuat Pelanggan CS... --</option>
                    </select>
                </div>
            @endif

            <div id="cs-log" class="cs-body" role="log"></div>

            <form id="cs-form" class="cs-footer">
                <input type="text" id="cs-input" placeholder="Tulis pesan ke CS Admin…" autocomplete="off" required>
                <button type="submit">Kirim</button>
            </form>
        @endif
    @endguest
</div>

<script src="/cs-widget.js" defer></script>
@stack('scripts')
</body>
</html>
