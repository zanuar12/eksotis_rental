@extends('layout')
@section('body')
<div class="page narrow">
    <a class="back" href="/chat">← Chat Operasional</a>
    <p class="eyebrow"><i></i> INTERNAL TIM / HANYA ADMIN & PETUGAS</p>
    <h1 class="pageTitle">Chat Internal Tim.</h1>

    <div class="inline subnav" style="margin-bottom:20px;">
        <a class="small secondary" href="/chat">🛵 Chat Pelanggan (Antar Unit)</a>
        <span class="small" style="background:#075747; color:#fff;">🔒 Chat Internal Tim</span>
    </div>

    <div class="notice" style="margin-bottom:16px;">
        <strong>Ruang Rahasia Tim:</strong> Ruang obrolan ini hanya dapat diakses oleh Admin dan Petugas. Pelanggan tidak dapat melihat percakapan di sini. Gunakan untuk instruksi penugasan, info armada, atau kondisi motor.
    </div>

    <div class="panel stack">
        <div id="log" class="chatlog" role="log" aria-live="polite" data-user="{{ auth()->id() }}"></div>
        <span id="state" class="hint" role="status"></span>
        <form method="post" class="stack" id="chat-form">
            @csrf
            <label>Pesan Internal
                <textarea name="body" maxlength="1500" placeholder="Ketik pesan internal untuk tim (Admin / Petugas)…"></textarea>
            </label>
            <div class="inline">
                <button type="button" class="secondary" id="loc">Pilih lokasi saya</button>
                <button>Kirim Pesan Internal →</button>
            </div>
            <div id="pin" hidden>
                <p id="coords"></p>
                <button type="button" class="small secondary" id="remove">Hapus titik</button>
            </div>
            <input type="hidden" name="latitude">
            <input type="hidden" name="longitude">
        </form>
    </div>
</div>
@endsection
@push('scripts')
<script src="/chat.js" defer></script>
@endpush

