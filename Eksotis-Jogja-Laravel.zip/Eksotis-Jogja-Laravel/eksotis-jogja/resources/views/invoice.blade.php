@extends('layout')
@section('title','Invoice digital')
@section('body')
@php($rp=[\App\Services\Rental::class,'rp'])
<div class="page narrow"><a class="back" href="/pesanan/{{$b->id}}">← Detail pesanan</a><article class="ticket"><p class="eyebrow"><i></i> EKSOTIS JOGJA / INVOICE DIGITAL</p><h1 class="pageTitle">{{$b->code}}</h1><p>Jl. Jombor Lor, Sinduadi, Mlati, Sleman, DIY</p><hr><dl><dt>Penyewa</dt><dd>{{$b->name}}</dd><dt>Motor</dt><dd>{{$b->motor}} · {{$b->unit}}</dd><dt>Periode</dt><dd>{{$b->start}} – {{$b->end}} WIB</dd><dt>Sewa</dt><dd>{{$rp($b->rent)}}</dd><dt>Pengantaran</dt><dd>{{$rp($b->fee)}}</dd><dt>Total</dt><dd><b>{{$rp($b->rent+$b->fee)}}</b></dd><dt>Dibayar</dt><dd>{{$rp($b->paid)}}</dd><dt>Sisa</dt><dd>{{$rp($b->rent+$b->fee-$b->paid)}}</dd></dl><button class="noprint" onclick="print()">Cetak / simpan PDF</button></article></div>
@endsection
