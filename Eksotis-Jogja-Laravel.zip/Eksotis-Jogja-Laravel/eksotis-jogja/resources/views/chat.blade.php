@extends('layout')
@section('body')
<div class="page narrow">
    <a class="back" href="{{ auth()->user()->role === 'pelanggan' ? '/pesanan' : '/chat' }}">← {{ auth()->user()->role === 'pelanggan' ? 'Pesanan' : 'Daftar Chat Operasional' }}</a>
    <p class="eyebrow"><i></i>
        @if(auth()->user()->role === 'admin')
            ADMIN / MONITORING OPERASIONAL
        @elseif(auth()->user()->role === 'petugas')
            PETUGAS / OPERASIONAL LAPANGAN
        @else
            EKSOTIS JOGJA / CHAT OPERASIONAL
        @endif
    </p>
    <h1 class="pageTitle">
        @if(auth()->user()->role === 'admin')
            Pantau Chat: {{ $customer->name }}
        @elseif(auth()->user()->role === 'petugas')
            Chat dengan {{ $customer->name }}
        @else
            Chat Petugas (Antar Unit)
        @endif
    </h1>

    <div class="notice" style="margin-bottom:16px;">
        @if(auth()->user()->role === 'admin')
            <strong>Mode Monitoring Admin:</strong> Anda dapat memantau percakapan antara petugas dan pelanggan, serta dapat ikut memberikan instruksi jika diperlukan.
        @elseif(auth()->user()->role === 'petugas')
            <strong>Ruang Koordinasi Antar Unit:</strong> Gunakan ruang ini untuk janjian serah terima motor, titik COD, atau penjemputan unit dengan pelanggan.
        @else
            <strong>Koordinasi Antar Unit:</strong> Gunakan chat ini untuk konfirmasi titik antar / COD dengan petugas lapangan (admin juga dapat memantau chat ini). Untuk bantuan CS, gunakan bubble di pojok kanan bawah.
        @endif
    </div>

    <div class="panel stack">
        <div id="log" class="chatlog" role="log" aria-live="polite" data-user="{{ auth()->id() }}"></div>
        <span id="state" class="hint" role="status"></span>
        <form method="post" class="stack" id="chat-form">
            @csrf
            <label>Pesan
                <textarea name="body" maxlength="1500" placeholder="Tulis pesan atau tempel tautan Google Maps…"></textarea>
            </label>
            <div class="inline">
                <button type="button" class="secondary" id="loc">Pilih lokasi saya</button>
                <button>Kirim →</button>
            </div>
            <div id="pin" hidden>
                <p id="coords"></p>
                <button type="button" class="small secondary" id="remove">Hapus titik</button>
            </div>
            <input type="hidden" name="latitude">
            <input type="hidden" name="longitude">
        </form>
    </div>

    <details>
        <summary>Peta lokasi rental Jombor</summary>
        <iframe title="Lokasi Eksotis Jogja" loading="lazy" src="https://maps.google.com/maps?q=Eksotis%20Jogja%20Jombor%20Sinduadi&amp;output=embed"></iframe>
    </details>
</div>
@endsection
@push('scripts')
<script src="/chat.js" defer></script>
@endpush
