@extends('layout')

@section('title', $register ? 'Daftar' : 'Masuk')

@section('body')
<div class="page narrow">
    <p class="eyebrow"><i></i> AKUN EKSOTIS JOGJA</p>
    <h1 class="pageTitle">{{ $register ? 'Buat akun pelanggan' : 'Selamat Datang' }}.</h1>

    <form class="panel stack" method="post">
        @csrf

        @if ($register)
            <label>
                Nama lengkap
                <input required name="name" autocomplete="name" value="{{ old('name') }}">
            </label>
        @endif

        <label>
            Email
            <input required type="email" name="email" autocomplete="email" value="{{ old('email') }}">
        </label>

        <label>
            Kata sandi
            <input required type="password" name="password" autocomplete="{{ $register ? 'new-password' : 'current-password' }}">
        </label>

        @if ($register)
            <label>
                Ulangi kata sandi
                <input required type="password" name="password_confirmation" autocomplete="new-password">
            </label>
            <small>Minimal 8 karakter.</small>
        @endif

        <button>{{ $register ? 'Daftar' : 'Masuk' }} →</button>
        <a class="textlink" href="{{ $register ? '/login' : '/daftar' }}">
            {{ $register ? 'Sudah punya akun? Masuk' : 'Baru di sini? Daftar akun' }}
        </a>
    </form>
</div>
@endsection
