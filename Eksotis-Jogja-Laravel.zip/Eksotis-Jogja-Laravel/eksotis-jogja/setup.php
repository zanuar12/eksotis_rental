<?php
// Jalankan dari terminal dengan "php setup.php".
if (PHP_SAPI !== 'cli') { http_response_code(403); exit; }
chdir(__DIR__);
if (version_compare(PHP_VERSION, '8.2.0', '<')) exit("Gunakan PHP 8.2 atau lebih baru.\n");
foreach (['pdo_sqlite','mbstring','openssl','dom','fileinfo','ctype','tokenizer','session','xml'] as $extension) {
    if (!extension_loaded($extension)) { fwrite(STDERR,"Aktifkan ekstensi $extension di php.ini, lalu ulangi.\n"); exit(1); }
}
if (!is_file('vendor/autoload.php')) { fwrite(STDERR,"Jalankan composer install terlebih dahulu.\n"); exit(1); }
if (!file_exists('.env') && !copy('.env.example','.env')) exit(1);
if (!file_exists('database/database.sqlite') && !touch('database/database.sqlite')) exit(1);
function artisanCommand(string $command): void {
    passthru(escapeshellarg(PHP_BINARY).' artisan '.$command, $status);
    if ($status !== 0) exit($status);
}
if (preg_match('/^APP_KEY=\s*$/m', file_get_contents('.env'))) artisanCommand('key:generate');
artisanCommand('migrate --seed');
echo "Siap. Jalankan php artisan serve dan buka http://127.0.0.1:8000\n";
