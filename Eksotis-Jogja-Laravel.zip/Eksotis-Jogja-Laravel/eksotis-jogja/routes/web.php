<?php
use App\Http\Controllers\{AccountController,BookingController,ChatController};
use Illuminate\Support\Facades\Route;

Route::get('/',[BookingController::class,'home']);
Route::view('/syarat','terms');
Route::middleware('guest')->group(function() {
    Route::view('/login','account',['register'=>false])->name('login');
    Route::view('/daftar','account',['register'=>true]);
    Route::post('/login',[AccountController::class,'login'])->middleware('throttle:10,1');
    Route::post('/daftar',[AccountController::class,'register'])->middleware('throttle:10,1');
});
Route::middleware('auth')->group(function() {
    Route::post('/keluar',[AccountController::class,'logout']);
    Route::get('/booking/{motor}',[BookingController::class,'form']);
    Route::post('/booking/{motor}',[BookingController::class,'store']);
    Route::get('/pesanan',[BookingController::class,'index']);
    Route::get('/pesanan/{id}',[BookingController::class,'show']);
    Route::post('/pesanan/{id}',[BookingController::class,'update']);
    Route::get('/pesanan/{id}/invoice',[BookingController::class,'show'])->name('invoice');
    Route::get('/chat',[ChatController::class,'inbox']);
    Route::match(['get','post'],'/chat/{customer}',[ChatController::class,'room'])->middleware('throttle:100,1');
    Route::match(['get','post'],'/chat-internal',[ChatController::class,'internalRoom'])->middleware('throttle:100,1');
    Route::get('/chat-cs/messages',[ChatController::class,'csMessages']);
    Route::post('/chat-cs/send',[ChatController::class,'csSend'])->middleware('throttle:60,1');
});

Route::get('/operasional',function () {
    abort_unless(auth()->user()->role==='admin',403);
    $units=\Illuminate\Support\Facades\DB::table('units as u')->join('motors as m','m.id','=','u.motor_id')
        ->select('u.code','m.name')->selectRaw("case when exists (select 1 from bookings b where b.unit_id=u.id and b.status in ('jalan','kembali')) then 'Sedang disewa' else 'Di rental' end as posisi")
        ->orderBy('m.name')->orderBy('u.code')->get();
    $groups=\Illuminate\Support\Facades\DB::table('bookings')->selectRaw('status, count(*) as jumlah, sum(paid) as dibayar')->groupBy('status')->get();
    return view('operations',compact('units','groups'));
})->middleware('auth');
