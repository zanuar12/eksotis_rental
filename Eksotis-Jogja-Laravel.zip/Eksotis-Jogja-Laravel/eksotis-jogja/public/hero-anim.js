document.addEventListener('DOMContentLoaded', () => {
    const poster = document.getElementById('hero-poster');
    const track = document.getElementById('poster-track');
    if (!poster || !track) return;

    const slides = track.querySelectorAll('.poster-slide');
    const dots = poster.querySelectorAll('.poster-dot');
    const prevBtn = document.getElementById('slide-prev');
    const nextBtn = document.getElementById('slide-next');
    if (slides.length <= 1) return;

    let current = 0;
    let timer = null;

    function goToSlide(index) {
        if (dots[current]) dots[current].classList.remove('active');
        if (slides[current]) slides[current].classList.remove('active');

        current = (index + slides.length) % slides.length;

        track.style.transform = `translateX(-${current * 100}%)`;

        if (dots[current]) dots[current].classList.add('active');
        if (slides[current]) slides[current].classList.add('active');
    }

    function nextSlide() {
        goToSlide(current + 1);
    }

    function prevSlide() {
        goToSlide(current - 1);
    }

    function startAutoPlay() {
        stopAutoPlay();
        timer = setInterval(nextSlide, 3800);
    }

    function stopAutoPlay() {
        if (timer) {
            clearInterval(timer);
            timer = null;
        }
    }

    dots.forEach((dot, idx) => {
        dot.addEventListener('click', () => {
            goToSlide(idx);
            startAutoPlay();
        });
    });

    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            prevSlide();
            startAutoPlay();
        });
    }

    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            nextSlide();
            startAutoPlay();
        });
    }

    poster.addEventListener('mouseenter', stopAutoPlay);
    poster.addEventListener('mouseleave', startAutoPlay);

    // Support touch swipe gestures on mobile
    let touchStartX = 0;
    poster.addEventListener('touchstart', (e) => {
        touchStartX = e.changedTouches[0].screenX;
        stopAutoPlay();
    }, { passive: true });

    poster.addEventListener('touchend', (e) => {
        const touchEndX = e.changedTouches[0].screenX;
        if (touchStartX - touchEndX > 45) {
            nextSlide();
        } else if (touchEndX - touchStartX > 45) {
            prevSlide();
        }
        startAutoPlay();
    }, { passive: true });

    // Click on slide to smoothly scroll down to fleet list
    slides.forEach(slide => {
        slide.style.cursor = 'pointer';
        slide.title = 'Klik untuk pilih motor ini';
        slide.addEventListener('click', (e) => {
            if (e.target.closest('.poster-nav') || e.target.closest('.poster-controls')) return;
            const target = document.getElementById('armada');
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });

    startAutoPlay();
});
