const form = document.querySelector('#catalog-search');
const status = document.querySelector('#catalog-result');
const details = document.querySelector('#query-details');
const graph = document.querySelector('#catalog-rdf').textContent;
const cards = [...document.querySelectorAll('[data-motor-id]')];
let graphReady;
let searchVersion = 0;

async function loadGraph() {
    const engine = await import('./oxigraph/web.js');
    const [schema] = await Promise.all([
        fetch('/semantik/ontologi.ttl').then(response => {
            if (!response.ok) throw new Error('Ontologi tidak termuat.');
            return response.text();
        }),
        engine.default(),
    ]);
    const store = new engine.Store();
    store.load(schema, {format: 'text/turtle'});
    store.load(graph, {format: 'application/ld+json'});
    return {store, literal: engine.literal};
}

function buildQuery(literal) {
    const conditions = [];
    const {brand, budget, available} = form.elements;
    if (brand.value) conditions.push('FILTER (?merek = ' + literal(brand.value).toString() + ')');
    if (budget.value !== '') conditions.push('FILTER (?biaya <= ' + budget.valueAsNumber + ')');
    if (available.checked) conditions.push('FILTER (?stok > 0)');

    return [
        'PREFIX ej: <urn:eksotis:sewa:>',
        'PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>',
        'SELECT DISTINCT ?id ?nama ?merek ?biaya ?stok WHERE {',
        '  ?penawaran a ej:Penawaran ; ej:untukMotor ?motor ;',
        '             ej:biayaSewa ?biaya ; ej:stok ?stok .',
        '  ?motor a/rdfs:subClassOf* ej:Motor ; ej:idModel ?id ;',
        '         rdfs:label ?nama ; ej:bermerek/rdfs:label ?merek .',
        ...conditions.map(condition => '  ' + condition),
        '} ORDER BY ?id',
    ].join('\n');
}

form.addEventListener('submit', async event => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const version = ++searchVersion;
    status.textContent = 'Mencari motor…';
    try {
        graphReady ??= loadGraph();
        const {store, literal} = await graphReady;
        if (version !== searchVersion || !form.reportValidity()) return;
        const query = buildQuery(literal);
        const rows = store.query(query);
        const ids = new Set(rows.map(row => row.get('id').value));
        cards.forEach(card => { card.hidden = !ids.has(card.dataset.motorId); });
        status.textContent = ids.size
            ? ids.size + ' tipe motor sesuai pilihanmu.'
            : 'Tidak ada motor yang cocok. Coba merek, bujet, atau jadwal lain.';
        document.querySelector('#catalog-query').textContent = query;
        details.hidden = false;
        const download = document.querySelector('#catalog-download');
        if (!download.hasAttribute('href')) {
            download.href = URL.createObjectURL(new Blob([graph], {type: 'application/ld+json'}));
        }
    } catch {
        if (version !== searchVersion) return;
        graphReady = undefined;
        cards.forEach(card => { card.hidden = false; });
        details.hidden = true;
        status.textContent = 'Pencarian semantik belum termuat. Semua motor ditampilkan. Tekan Cari motor untuk mencoba lagi.';
    }
});

form.addEventListener('reset', () => {
    ++searchVersion;
    cards.forEach(card => { card.hidden = false; });
    status.textContent = 'Semua motor ditampilkan.';
    details.hidden = true;
});
