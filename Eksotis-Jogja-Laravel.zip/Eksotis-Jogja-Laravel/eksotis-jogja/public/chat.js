const log=document.querySelector('#log'), form=document.querySelector('#chat-form'), state=document.querySelector('#state');
let last=0;
function mapLink(url,label){
    const a=document.createElement('a'); a.href=url; a.target='_blank'; a.rel='noopener noreferrer'; a.textContent=label; return a;
}
function render(msg){
    const bubble=document.createElement('div');
    bubble.className='bubble'+(String(msg.sender_id)===log.dataset.user?' mine':'');
    const who=document.createElement('small'); who.textContent=msg.name+' · '+msg.created_at.slice(11,16)+' WIB'; bubble.append(who);
    if(msg.body){
        for(const part of msg.body.split(/(https?:\/\/[^\s]+)/g)){
            let url;try{url=new URL(part)}catch{}
            if(url && ['maps.app.goo.gl','maps.google.com','www.google.com','maps.google.co.id','www.google.co.id'].includes(url.hostname)) bubble.append(mapLink(url.href,part));
            else bubble.append(document.createTextNode(part));
        }
    }
    if(msg.latitude!==null){
        const q=Number(msg.latitude)+','+Number(msg.longitude);
        bubble.append(mapLink('https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(q),'📍 Buka titik di Google Maps'));
        const map=document.createElement('iframe');map.title='Titik lokasi yang dibagikan';map.loading='lazy';
        map.src='https://maps.google.com/maps?q='+encodeURIComponent(q)+'&z=16&output=embed';bubble.append(map);
    }
    log.append(bubble);
}
async function refresh(){
    try{
        const r=await fetch(location.pathname+'?after='+last,{headers:{Accept:'application/json'},cache:'no-store'});
        if(!r.ok) throw Error();
        const rows=await r.json(); if(rows.length){
            const nearBottom=log.scrollHeight-log.scrollTop-log.clientHeight<80;
            for(const row of rows){render(row);last=row.id}
            if(nearBottom) log.scrollTop=log.scrollHeight;
        }
        state.textContent=last?'Pesan diperbarui otomatis.':'Belum ada pesan. Mulai percakapan di bawah.';
    } catch {state.textContent='Percakapan belum tersambung. Mencoba kembali…'}
    setTimeout(refresh,3500);
}
refresh();
const pin=document.querySelector('#pin'), loc=document.querySelector('#loc');
loc.onclick=()=>{
    if(!navigator.geolocation){state.textContent='GPS tidak tersedia. Tempel tautan Google Maps pada pesan.';return}
    loc.disabled=true;loc.textContent='Mencari posisi…';
    const reset=()=>{loc.disabled=false;loc.textContent='Pilih lokasi saya'};
    navigator.geolocation.getCurrentPosition(pos=>{
        form.elements.latitude.value=pos.coords.latitude.toFixed(7);form.elements.longitude.value=pos.coords.longitude.toFixed(7);
        pin.hidden=false;document.querySelector('#coords').textContent='Titik siap dikirim: '+form.elements.latitude.value+', '+form.elements.longitude.value;reset();
    },()=>{alert('Lokasi gagal diakses. Izinkan GPS atau tempel tautan Google Maps.');reset()},{timeout:12000});
};
document.querySelector('#remove').onclick=()=>{form.elements.latitude.value='';form.elements.longitude.value='';pin.hidden=true};
form.onsubmit=e=>{if(!form.elements.body.value.trim()&&!form.elements.latitude.value){e.preventDefault();form.elements.body.focus()}};
