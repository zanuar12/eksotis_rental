document.addEventListener('DOMContentLoaded', () => {
    const btn = document.getElementById('cs-floating-btn');
    const win = document.getElementById('cs-chat-window');
    const closeBtn = document.getElementById('cs-close-btn');
    const log = document.getElementById('cs-log');
    const form = document.getElementById('cs-form');
    const input = document.getElementById('cs-input');
    const select = document.getElementById('cs-select-customer');
    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';

    if (!btn || !win) return;

    let lastId = 0;
    let pollTimer = null;
    const role = win.dataset.role || 'guest';
    const userId = win.dataset.userId || '';

    btn.addEventListener('click', () => {
        const isOpen = win.classList.toggle('active');
        if (isOpen) {
            startPolling();
            if (input) input.focus();
        } else {
            stopPolling();
        }
    });

    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            win.classList.remove('active');
            stopPolling();
        });
    }

    if (select) {
        select.addEventListener('change', () => {
            lastId = 0;
            if (log) log.innerHTML = '';
            fetchMessages();
        });
    }

    function renderMessage(msg) {
        if (!log) return;
        const bubble = document.createElement('div');
        bubble.className = 'bubble' + (String(msg.sender_id) === String(userId) ? ' mine' : '');
        
        const who = document.createElement('small');
        const roleLabel = msg.role === 'admin' ? ' (CS)' : '';
        const time = (msg.created_at || '').slice(11, 16);
        who.textContent = (msg.name || 'User') + roleLabel + (time ? ' · ' + time + ' WIB' : '');
        bubble.appendChild(who);

        if (msg.body) {
            const textNode = document.createTextNode(msg.body);
            bubble.appendChild(textNode);
        }

        log.appendChild(bubble);
    }

    async function fetchMessages() {
        if (!win.classList.contains('active')) return;
        if (role === 'guest' || role === 'petugas') return;

        let url = '/chat-cs/messages?after=' + lastId;
        if (role === 'admin') {
            const customerId = select ? select.value : '';
            if (!customerId) {
                // Ambil daftar customer jika select masih kosong
                try {
                    const res = await fetch('/chat-cs/messages');
                    const data = await res.json();
                    if (data.customers && select && select.options.length <= 1) {
                        select.innerHTML = '<option value="">-- Pilih Pelanggan --</option>';
                        data.customers.forEach(c => {
                            const opt = document.createElement('option');
                            opt.value = c.id;
                            opt.textContent = c.name + ' (' + c.email + ')';
                            select.appendChild(opt);
                        });
                    }
                } catch(e) {}
                return;
            }
            url += '&customer_id=' + customerId;
        }

        try {
            const res = await fetch(url, { credentials: 'same-origin', headers: { 'Accept': 'application/json' }, cache: 'no-store' });
            if (!res.ok) return;
            const messages = await res.json();
            if (Array.isArray(messages) && messages.length > 0) {
                const nearBottom = log.scrollHeight - log.scrollTop - log.clientHeight < 80;
                messages.forEach(m => {
                    renderMessage(m);
                    lastId = Math.max(lastId, m.id);
                });
                if (nearBottom) {
                    log.scrollTop = log.scrollHeight;
                }
            }
        } catch (e) {}
    }

    function startPolling() {
        fetchMessages();
        if (!pollTimer) {
            pollTimer = setInterval(fetchMessages, 3500);
        }
    }

    function stopPolling() {
        if (pollTimer) {
            clearInterval(pollTimer);
            pollTimer = null;
        }
    }

    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const text = (input?.value || '').trim();
            if (!text) return;

            let payload = { body: text };
            if (role === 'admin') {
                const customerId = select ? select.value : '';
                if (!customerId) {
                    alert('Silakan pilih pelanggan terlebih dahulu.');
                    return;
                }
                payload.customer_id = customerId;
            }

            input.value = '';
            try {
                const res = await fetch('/chat-cs/send', {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: JSON.stringify(payload)
                });
                if (res.ok) {
                    const newMsg = await res.json();
                    renderMessage(newMsg);
                    lastId = Math.max(lastId, newMsg.id);
                    log.scrollTop = log.scrollHeight;
                } else {
                    const err = await res.json();
                    alert(err.error || 'Gagal mengirim pesan.');
                }
            } catch (e) {
                alert('Gagal mengirim pesan. Silakan coba kembali.');
            }
        });
    }
});

