<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder {
    public function run(): void {
        DB::transaction(function () {
            foreach ([
                ['Honda Beat FI','beat',16,80000,85000,510000,2200000],
                ['Honda Vario 125','vario',7,100000,110000,650000,2800000],
                ['Yamaha Mio GT','mio',1,80000,85000,510000,2200000],
                ['Honda Beat Street','street',2,85000,90000,545000,2350000],
                ['Yamaha NMAX','nmax',6,135000,145000,895000,3850000],
                ['Yamaha Fazzio','fazzio',3,95000,105000,615000,2650000],
            ] as [$name,$image,$count,$daily,$weekend,$weekly,$monthly]) {
                DB::table('motors')->updateOrInsert(['name'=>$name],compact('image','daily','weekend','weekly','monthly'));
                $motor=DB::table('motors')->where('name',$name)->value('id');
                for ($i=1;$i<=$count;$i++) DB::table('units')->updateOrInsert(['code'=>strtoupper($image).'-'.sprintf('%02d',$i)],['motor_id'=>$motor]);
            }
            if (app()->environment('local','testing')) {
                foreach (['admin','petugas','pelanggan'] as $role) {
                    $email=$role.'@gmail.com';
                    if (!DB::table('users')->where('email',$email)->exists())
                        DB::table('users')->insert(['email'=>$email,'name'=>ucfirst($role),'role'=>$role,'password'=>Hash::make('eksotis123')]);
                }
            }
        });
    }
}
