<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::table('users', fn(Blueprint $t) => $t->string('role')->default('pelanggan'));
        Schema::create('motors', function(Blueprint $t) {
            $t->id(); $t->string('name'); $t->string('image');
            foreach (['daily','weekend','weekly','monthly'] as $rate) $t->unsignedInteger($rate);
        });
        Schema::create('units', function(Blueprint $t) {
            $t->id(); $t->foreignId('motor_id')->constrained(); $t->string('code')->unique();
        });
        Schema::create('bookings', function(Blueprint $t) {
            $t->id(); $t->string('code')->unique(); $t->foreignId('user_id')->constrained();
            $t->foreignId('unit_id')->constrained(); $t->dateTime('start'); $t->dateTime('end');
            $t->index(['unit_id','start','end']); $t->string('name'); $t->string('phone');
            $t->text('identity'); $t->string('province'); $t->string('pickup');
            $t->text('address')->nullable(); $t->string('status'); $t->unsignedInteger('rent');
            $t->unsignedInteger('fee')->default(0); $t->decimal('distance',5,2)->nullable();
            $t->unsignedInteger('paid')->default(0); $t->unsignedInteger('submitted')->default(0);
            $t->string('method')->nullable(); $t->string('reference')->nullable();
            $t->dateTime('handed_at')->nullable(); $t->dateTime('returned_at')->nullable();
            $t->text('condition')->nullable(); $t->timestamps();
        });
        Schema::create('messages',function(Blueprint $t) {
            $t->id(); $t->foreignId('customer_id')->constrained('users'); $t->foreignId('sender_id')->constrained('users');
            $t->text('body')->nullable(); $t->decimal('latitude',10,7)->nullable(); $t->decimal('longitude',10,7)->nullable(); $t->timestamps();
        });
    }
    public function down(): void {
        foreach (['messages','bookings','units','motors'] as $table) Schema::dropIfExists($table);
        Schema::table('users', fn(Blueprint $t) => $t->dropColumn('role'));
    }
};
