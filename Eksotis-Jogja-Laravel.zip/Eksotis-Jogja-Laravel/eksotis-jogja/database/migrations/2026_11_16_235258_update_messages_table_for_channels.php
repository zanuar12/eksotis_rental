<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::table('messages', function (Blueprint $table) {
            $table->string('channel', 32)->default('operasional');
            $table->foreignId('customer_id')->nullable()->change();
        });
    }

    public function down(): void {
        Schema::table('messages', function (Blueprint $table) {
            $table->dropColumn('channel');
        });
    }
};
