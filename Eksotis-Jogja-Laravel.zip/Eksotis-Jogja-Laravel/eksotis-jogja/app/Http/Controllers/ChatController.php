<?php
namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ChatController extends Controller {

    // 1. INBOX CHAT OPERASIONAL (Petugas & Pelanggan, Admin memantau)
    public function inbox(Request $r) {
        $user = $r->user();
        if ($user->role === 'pelanggan') {
            return redirect('/chat/' . $user->id);
        }

        abort_unless(in_array($user->role, ['admin', 'petugas']), 403);
        $customers = User::where('role', 'pelanggan')->orderBy('name')->get();
        return view('inbox', compact('customers'));
    }

    // 2. ROOM CHAT OPERASIONAL
    public function room(Request $r, User $customer) {
        $user = $r->user();
        abort_unless(
            $customer->role === 'pelanggan' &&
            ($user->id === $customer->id || in_array($user->role, ['admin', 'petugas'])),
            403
        );

        $query = DB::table('messages as m')
            ->join('users as u', 'u.id', '=', 'm.sender_id')
            ->where(function ($q) {
                $q->where('m.channel', 'operasional')->orWhereNull('m.channel');
            })
            ->where('m.customer_id', $customer->id)
            ->select('m.*', 'u.name', 'u.role')
            ->orderBy('m.id');

        if ($r->isMethod('post')) {
            $data = $r->validate([
                'body' => 'nullable|required_without:latitude|string|max:1500',
                'latitude' => 'nullable|required_with:longitude|numeric|between:-90,90',
                'longitude' => 'nullable|required_with:latitude|numeric|between:-180,180'
            ]);
            DB::table('messages')->insert($data + [
                'channel' => 'operasional',
                'customer_id' => $customer->id,
                'sender_id' => $user->id,
                'created_at' => now(),
                'updated_at' => now()
            ]);
            return redirect('/chat/' . $customer->id);
        }

        if ($r->expectsJson()) {
            return response()->json(
                $query->where('m.id', '>', $r->integer('after'))->limit(150)->get()
            )->header('Cache-Control', 'no-store');
        }

        return view('chat', compact('customer'));
    }

    // 3. CHAT INTERNAL (Hanya Admin & Petugas)
    public function internalRoom(Request $r) {
        $user = $r->user();
        abort_unless(in_array($user->role, ['admin', 'petugas']), 403);

        $query = DB::table('messages as m')
            ->join('users as u', 'u.id', '=', 'm.sender_id')
            ->where('m.channel', 'internal')
            ->select('m.*', 'u.name', 'u.role')
            ->orderBy('m.id');

        if ($r->isMethod('post')) {
            $data = $r->validate([
                'body' => 'nullable|required_without:latitude|string|max:1500',
                'latitude' => 'nullable|required_with:longitude|numeric|between:-90,90',
                'longitude' => 'nullable|required_with:latitude|numeric|between:-180,180'
            ]);
            DB::table('messages')->insert($data + [
                'channel' => 'internal',
                'customer_id' => null,
                'sender_id' => $user->id,
                'created_at' => now(),
                'updated_at' => now()
            ]);
            return redirect('/chat-internal');
        }

        if ($r->expectsJson()) {
            return response()->json(
                $query->where('m.id', '>', $r->integer('after'))->limit(150)->get()
            )->header('Cache-Control', 'no-store');
        }

        return view('chat-internal');
    }

    // 4. CS FLOATING BUBBLE: Ambil pesan
    public function csMessages(Request $r) {
        $user = $r->user();
        if (!$user) return response()->json(['error' => 'Unauthenticated'], 401);
        if ($user->role === 'petugas') return response()->json(['error' => 'Petugas tidak mengelola CS'], 403);

        $targetCustomerId = $user->role === 'admin' ? $r->integer('customer_id') : $user->id;

        // Jika admin belum memilih customer, berikan daftar customer
        if ($user->role === 'admin' && !$targetCustomerId) {
            $customers = DB::table('users')
                ->where('role', 'pelanggan')
                ->select('id', 'name', 'email')
                ->orderBy('name')
                ->get();
            return response()->json(['customers' => $customers]);
        }

        $query = DB::table('messages as m')
            ->join('users as u', 'u.id', '=', 'm.sender_id')
            ->where('m.channel', 'cs')
            ->where('m.customer_id', $targetCustomerId)
            ->select('m.*', 'u.name', 'u.role')
            ->orderBy('m.id');

        $rows = $query->where('m.id', '>', $r->integer('after'))->limit(150)->get();
        return response()->json($rows)->header('Cache-Control', 'no-store');
    }

    // 5. CS FLOATING BUBBLE: Kirim pesan
    public function csSend(Request $r) {
        $user = $r->user();
        if (!$user) return response()->json(['error' => 'Unauthenticated'], 401);
        if ($user->role === 'petugas') return response()->json(['error' => 'Forbidden'], 403);

        $targetCustomerId = $user->role === 'admin' ? $r->integer('customer_id') : $user->id;
        if (!$targetCustomerId) return response()->json(['error' => 'Pelanggan tujuan tidak valid'], 422);

        $data = $r->validate([
            'body' => 'required|string|max:1500',
        ]);

        $id = DB::table('messages')->insertGetId([
            'channel' => 'cs',
            'customer_id' => $targetCustomerId,
            'sender_id' => $user->id,
            'body' => $data['body'],
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json([
            'id' => $id,
            'body' => $data['body'],
            'sender_id' => $user->id,
            'name' => $user->name,
            'role' => $user->role,
            'created_at' => now()->toIso8601String(),
        ]);
    }
}
