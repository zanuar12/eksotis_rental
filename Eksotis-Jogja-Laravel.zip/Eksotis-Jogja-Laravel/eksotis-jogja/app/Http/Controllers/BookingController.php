<?php
namespace App\Http\Controllers;
use App\Services\Rental;
use App\Services\CatalogGraph;
use Carbon\CarbonImmutable;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\{DB,Crypt};
use Illuminate\Support\Str;
use Illuminate\Validation\{Rule,ValidationException};

class BookingController extends Controller {
    private function schedule(Request $request): array
    {
        $validator = validator($request->only('start', 'end'), [
            'start' => 'required|date_format:Y-m-d\TH:i',
            'end' => 'required|date_format:Y-m-d\TH:i|after:start',
        ], [
            'required' => 'Pilih tanggal dan jam mulai serta pengembalian.',
            'date_format' => 'Gunakan tanggal dan jam yang valid.',
            'end.after' => 'Pengembalian harus sesudah waktu mulai sewa.',
        ]);
        $catalogUrl = url('/').'#armada';
        if ($validator->fails()) {
            throw (new ValidationException($validator))->redirectTo($catalogUrl);
        }

        $start = CarbonImmutable::parse($request->start);
        $end = CarbonImmutable::parse($request->end);
        if ($start->lt(now()->startOfMinute())) {
            throw ValidationException::withMessages(['start' => 'Waktu mulai sudah lewat. Pilih jadwal baru.'])->redirectTo($catalogUrl);
        }
        if ($end->timestamp - $start->timestamp < 86400) {
            throw ValidationException::withMessages(['end' => 'Sewa minimal 24 jam.'])->redirectTo($catalogUrl);
        }
        return [$start, $end];
    }
    public function home(Request $r) {
        $filtered=$r->hasAny(['start','end']);
        [$start,$end]=$filtered ? $this->schedule($r) : [now()->addDay()->setTime(9,0)->toImmutable(),now()->addDays(2)->setTime(9,0)->toImmutable()];
        $motors=DB::table('motors')->get();
        foreach ($motors as $m) {
            $m->brand = Str::before($m->name, ' ');
            $m->free=Rental::freeUnits($m->id,$start,$end)->count();
            $m->quote=Rental::price($m,$start,$end);
        }
        $catalogGraph = CatalogGraph::forSchedule($motors, $start, $end);
        return view('home', compact('motors', 'start', 'end', 'catalogGraph'));
    }
    public function form(Request $r,int $motor) {
        abort_unless($r->user()->role==='pelanggan',403);
        [$start,$end]=$this->schedule($r);
        $m=DB::table('motors')->find($motor); abort_unless($m,404);
        if (!Rental::freeUnits($motor,$start,$end)->exists()) return redirect('/#armada')->withErrors(['unit'=>'Motor tidak tersedia. Pilih motor atau jadwal lain.']);
        return view('booking',compact('m','start','end'));
    }
    public function store(Request $request, int $motor)
    {
        $userId = $request->user()->id;
        abort_unless($request->user()->role === 'pelanggan', 403);
        $data = $request->validate([
            'request_key' => 'nullable|uuid',
            'name' => 'required|string|max:100',
            'phone' => 'required|regex:/^[+0-9 ()-]{8,22}$/',
            'nik' => 'required|digits:16',
            'province' => ['required', Rule::in(config('provinces'))],
            'pickup' => 'required|in:rental,cod',
            'address' => 'required_if:pickup,cod|nullable|string|max:500',
        ]);
        if ($data['province'] === 'Daerah Istimewa Yogyakarta') {
            throw ValidationException::withMessages(['province' => 'Mohon maaf, pemesanan rental motor tidak dapat dilakukan menggunakan KTP berdomisili Yogyakarta sesuai kebijakan rental.']);
        }

        $id = DB::transaction(function () use ($request, $data, $userId, $motor) {
            if (!empty($data['request_key'])) {
                $existing = DB::table('bookings')->where('user_id', $userId)
                    ->where('request_key', $data['request_key'])->value('id');
                if ($existing !== null) {
                    return $existing;
                }
            }

            [$start, $end] = $this->schedule($request);
            $model = DB::table('motors')->find($motor);
            abort_unless($model, 404);
            $unit = Rental::freeUnits($motor, $start, $end)->orderBy('id')->value('id');
            if ($unit === null) {
                throw ValidationException::withMessages(['unit' => 'Motor tidak tersedia. Pilih motor atau jadwal lain.'])->redirectTo(url('/').'#armada');
            }

            return DB::table('bookings')->insertGetId([
                'code' => 'EJ-'.strtoupper(Str::random(9)),
                'request_key' => $data['request_key'] ?? null,
                'user_id' => $userId,
                'unit_id' => $unit,
                'start' => $start,
                'end' => $end,
                'name' => $data['name'],
                'phone' => $data['phone'],
                'identity' => Crypt::encryptString($data['nik']),
                'province' => $data['province'],
                'pickup' => $data['pickup'],
                'address' => $data['pickup'] === 'cod' ? $data['address'] : null,
                'status' => $data['pickup'] === 'cod' ? 'cod' : 'bayar',
                'rent' => Rental::price($model, $start, $end),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }, 5);
        return redirect('/pesanan/'.$id);
    }
    public function index(Request $r) {
        $query=Rental::bookings();
        if ($r->user()->role==='pelanggan') $query->where('user_id',$r->user()->id);
        if ($r->filled('q')) $query->where('b.code','like','%'.$r->validate(['q'=>'string|max:40'])['q'].'%');
        if ($r->filled('status')) $query->where('b.status',$r->validate(['status'=>['string',Rule::in(array_keys(Rental::STATUS))]])['status']);
        return view('orders',['orders'=>$query->latest('b.id')->paginate(20)->withQueryString()]);
    }
    public function show(Request $r,int $id) {
        $b=Rental::bookings()->where('b.id',$id)->first(); abort_unless($b,404);
        abort_if($r->user()->role==='pelanggan' && $b->user_id!==$r->user()->id,403);
        if ($r->routeIs('invoice')) {
            abort_unless(in_array($b->status,['siap','jalan','kembali','selesai']),403);
            return view('invoice',compact('b'));
        }
        return view('detail',compact('b'));
    }
    public function update(Request $r,int $id) {
        DB::transaction(function() use ($r,$id) {
            $b=DB::table('bookings')->find($id); abort_unless($b,404);
            $role=$r->user()->role; $admin=$role==='admin'; $staff=in_array($role,['admin','petugas']);
            $owner=$r->user()->id===$b->user_id; $total=$b->rent+$b->fee;
            $action=$r->input('action'); $changes=[];
            if ($owner && $action==='cancel' && in_array($b->status,['cod','alternatif','bayar'])) $next='batal';
            elseif ($admin && $b->status==='cod' && $action==='review') {
                $r->validate(['distance'=>'required|numeric|min:0|max:999','fee'=>'nullable|integer|min:0|max:30000']);
                $km=(float)$r->distance; $fee=(int)$r->fee;
                if ($km>2 && $km<=9 && $fee<15000) throw ValidationException::withMessages(['fee'=>'Masukkan ongkir Rp15.000–Rp30.000 untuk jarak ini.']);
                $next=$km>9?'alternatif':'bayar'; $changes=['distance'=>$km,'fee'=>$km>2 && $km<=9?$fee:0];
            } elseif ($owner && $b->status==='alternatif' && $action==='pickup') {
                $next='bayar'; $changes=['pickup'=>'rental','address'=>null,'fee'=>0];
            } elseif ($owner && $b->status==='bayar' && $action==='pay') {
                $r->validate(['plan'=>'required|in:dp,full','method'=>'required|in:Transfer,QRIS','reference'=>'required|string|max:100']);
                $next='periksa'; $changes=['submitted'=>$r->plan==='dp'?50000:$total,'reference'=>$r->reference,'method'=>$r->method];
            } elseif ($admin && $b->status==='periksa' && in_array($action,['verify','reject'])) {
                $next=$action==='verify'?'siap':'bayar'; $changes=['paid'=>$action==='verify'?$b->submitted:0];
            } elseif ($staff && $b->status==='siap' && $action==='handover') {
                $r->validate(['confirm'=>'accepted']);
                $time = now();
                if ($time->lt($b->start) || $time->gte($b->end)) {
                    throw ValidationException::withMessages(['start' => 'Serah terima dapat dicatat mulai '.$b->start.' WIB dan sebelum '.$b->end.' WIB.']);
                }
                if (DB::table('bookings')->where('unit_id',$b->unit_id)->whereIn('status',['jalan','kembali'])->exists())
                    throw ValidationException::withMessages(['unit'=>'Unit sebelumnya belum dikembalikan.']);
                $next='jalan'; $changes=['paid'=>$total,'handed_at'=>now()];
            } elseif ($owner && $b->status==='jalan' && $action==='return') $next='kembali';
            elseif ($staff && in_array($b->status,['kembali','jalan']) && $action==='close') {
                $r->validate(['condition'=>'required|string|max:500']); $next='selesai';
                $changes=['condition'=>$r->condition,'returned_at'=>now()];
            } else abort(403);
            DB::table('bookings')->where('id',$id)->update($changes+['status'=>$next,'updated_at'=>now()]);
        },3);
        return redirect('/pesanan/'.$id)->with('ok','Status pesanan diperbarui.');
    }
}
