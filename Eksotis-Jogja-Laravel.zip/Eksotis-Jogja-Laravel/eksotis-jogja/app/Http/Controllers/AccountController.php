<?php
namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AccountController extends Controller {
    public function login(Request $r) {
        $data=$r->validate(['email'=>'required|email','password'=>'required|string']);
        if (!Auth::attempt($data)) return back()->withErrors(['email'=>'Email atau kata sandi belum sesuai.'])->onlyInput('email');
        $r->session()->regenerate();
        return redirect()->intended(auth()->user()->role==='pelanggan' ? '/' : '/pesanan');
    }
    public function register(Request $r) {
        $data=$r->validate(['name'=>'required|string|max:100','email'=>'required|email|max:150|unique:users','password'=>'required|string|min:8|confirmed']);
        Auth::login(User::create($data)); $r->session()->regenerate(); return redirect()->intended('/');
    }
    public function logout(Request $r) {
        Auth::logout(); $r->session()->invalidate(); $r->session()->regenerateToken(); return redirect('/');
    }
}
