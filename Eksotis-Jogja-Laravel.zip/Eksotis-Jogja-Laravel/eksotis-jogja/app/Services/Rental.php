<?php
namespace App\Services;
use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\DB;

class Rental {
    public const STATUS = [
        'cod'=>'Periksa alamat COD','alternatif'=>'Pilih pengambilan lain','bayar'=>'Menunggu pembayaran',
        'periksa'=>'Verifikasi pembayaran','siap'=>'Booking terkonfirmasi','jalan'=>'Sedang disewa',
        'kembali'=>'Pengembalian diajukan','selesai'=>'Selesai','batal'=>'Dibatalkan'
    ];
    public static function freeUnits($motor,$start,$end) {
        return DB::table('units')->where('motor_id',$motor)->whereNotExists(function($q) use ($start,$end) {
            $q->selectRaw('1')->from('bookings as b')->whereColumn('b.unit_id','units.id')
              ->whereNotIn('b.status',['batal','selesai'])->where('b.start','<',$end)
              ->where(function($w) use($start) {
                  $w->where('b.end','>',$start)->orWhere(function($late) {
                      $late->whereIn('b.status',['jalan','kembali'])->where('b.end','<=',now());
                  });
              });
        });
    }
    public static function price($motor,CarbonImmutable $start,CarbonImmutable $end): int {
        $days=(int)ceil(($end->timestamp-$start->timestamp)/86400);
        $months=intdiv($days,30); $weeks=intdiv($days%30,7);
        $cost=$months*$motor->monthly+$weeks*$motor->weekly;
        for ($i=$months*30+$weeks*7;$i<$days;$i++)
            $cost+=$start->addDays($i)->isWeekend() ? $motor->weekend : $motor->daily;
        return $cost;
    }
    public static function bookings() {
        return DB::table('bookings as b')->join('units as u','u.id','=','b.unit_id')
            ->join('motors as m','m.id','=','u.motor_id')
            ->select('b.*','u.code as unit','m.name as motor','m.image');
    }
    public static function rp($v): string { return 'Rp'.number_format($v,0,',','.'); }
}
