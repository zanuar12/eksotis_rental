<?php

namespace App\Services;

use Carbon\CarbonImmutable;
use Illuminate\Support\Collection;

class CatalogGraph
{
    /** Build RDF from the same public offers that are shown on the cards. */
    public static function forSchedule(Collection $motors, CarbonImmutable $start, CarbonImmutable $end): array
    {
        $offers = [];
        foreach ($motors as $motor) {
            $offers[] = [
                '@id' => "urn:eksotis:penawaran:{$motor->id}:{$start->timestamp}:{$end->timestamp}",
                '@type' => 'ej:Penawaran',
                'ej:mulai' => ['@value' => $start->toIso8601String(), '@type' => 'xsd:dateTime'],
                'ej:kembali' => ['@value' => $end->toIso8601String(), '@type' => 'xsd:dateTime'],
                'ej:biayaSewa' => (int) $motor->quote,
                'ej:stok' => (int) $motor->free,
                'ej:untukMotor' => [
                    '@id' => "urn:eksotis:motor:{$motor->id}",
                    '@type' => 'ej:MotorMatik',
                    'ej:idModel' => (int) $motor->id,
                    'rdfs:label' => $motor->name,
                    'ej:bermerek' => [
                        '@id' => 'urn:eksotis:merek:'.rawurlencode($motor->brand),
                        '@type' => 'ej:Merek',
                        'rdfs:label' => $motor->brand,
                    ],
                ],
            ];
        }

        return [
            '@context' => [
                'ej' => 'urn:eksotis:sewa:',
                'rdfs' => 'http://www.w3.org/2000/01/rdf-schema#',
                'xsd' => 'http://www.w3.org/2001/XMLSchema#',
            ],
            '@graph' => $offers,
        ];
    }
}
