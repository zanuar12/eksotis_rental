# Eksotis Jogja — Sistem Informasi Penyewaan Motor
Proyek tugas berbasis Laravel 12, Blade, CSS, JavaScript, dan SQLite. Seluruh kode aplikasi bisa dibuka di VS Code. Dependensi PHP disertakan agar percobaan pertama lebih mudah.

## Menjalankan di Windows / macOS / Linux
1. Ekstrak ZIP sampai terlihat folder yang berisi **artisan**, **setup.php**, dan **composer.json**. Buka folder tersebut di VS Code, lalu pilih Terminal → New Terminal.
2. Ketik `php -v`. Gunakan PHP 8.2 atau lebih baru dengan SQLite dan ekstensi standar Laravel. Untuk XAMPP Windows, contoh perintah jika PHP belum terdaftar di PATH adalah `C:\xampp\php\php.exe setup.php`. Periksa konfigurasi aktif dengan `php --ini`. Bila muncul pesan ekstensi belum aktif, buka php.ini tersebut, aktifkan ekstensi yang diminta (misalnya extension=pdo_sqlite, extension=mbstring), simpan, lalu ulangi perintah.
3. Jalankan kedua perintah berikut.
   
   ```sh
   php setup.php
   php artisan serve
   ```
4. Buka http://127.0.0.1:8000. Biarkan terminal tetap terbuka. Di hari berikutnya cukup jalankan `php artisan serve`. Data tersimpan dalam database/database.sqlite. Setup dapat dijalankan ulang tanpa menghapus pesanan atau mengganti kunci. Jika folder vendor pernah dihapus, jalankan `composer install` terlebih dahulu.

## Memperbarui proyek yang sudah memiliki pesanan

Hentikan server lama dengan Ctrl+C. Ekstrak ZIP baru di folder terpisah. Salin file `.env` dan `database/database.sqlite` dari proyek lama ke lokasi yang sama di proyek baru sebelum menjalankan `php setup.php`. Kedua file ini berpasangan karena kunci pada `.env` digunakan untuk membaca NIK terenkripsi. Setup menambahkan kolom pelindung pengiriman booking berulang melalui migrasi Laravel. Proyek yang baru pertama kali dipasang cukup mengikuti empat langkah instalasi di atas.

## Akun percobaan lokal
| Peran | Email | Kata sandi |
|---|---|---|
| Pelanggan | pelanggan@gmail.com | eksotis123 |
| Admin | admin@gmail.com | eksotis123 |
| Petugas | petugas@gmail.com | eksotis123 |

Pelanggan juga dapat mendaftar sendiri. Untuk mencoba dua peran bersamaan, gunakan satu jendela biasa dan satu jendela samaran atau profil browser berbeda. Akun demo dibuat ketika lingkungan aplikasi bernilai local/testing. Gunakan NIK, nomor HP dan referensi transaksi fiktif.

## Skenario presentasi singkat
1. **Cek jadwal.** Pada halaman utama pilih waktu mulai dan kembali dalam WIB, minimal 24 jam. Tiap kartu menampilkan jumlah unit yang masih kosong serta total biaya periode itu. Pilih Yamaha Mio GT untuk memperlihatkan simulasi kehabisan stok karena hanya ada satu unit.
   - Buka **Pencarian semantik** di bawah formulir jadwal. Untuk contoh satu hari kerja, pilih Yamaha, masukkan bujet Rp85.000, lalu centang **Hanya yang tersedia**. Pada data awal, Yamaha Mio GT cocok, sedangkan harga Yamaha Fazzio dan NMAX melebihi bujet. Setelah Mio dipesan penuh, cek kembali jadwal yang sama dan ulangi pencarian.
   - Pada **Lihat kueri SPARQL** kamu dapat membaca kueri yang benar-benar dijalankan serta mengunduh ontologi Turtle dan data penawaran JSON-LD. Data publik berisi model motor, merek, jadwal, biaya, dan stok.
2. **Booking.** Klik Pesan, masuk sebagai pelanggan, isi identitas. Coba provinsi Daerah Istimewa Yogyakarta untuk melihat pesan penolakan. Pilih Jawa Tengah dengan NIK fiktif 16 digit untuk melanjutkan.
3. **COD.** Isi alamat dan patokan. Setelah booking tersimpan, buka **Chat Petugas (Antar Unit)**, pilih lokasi saya, beri izin lokasi dan tekan Kirim (admin juga dapat memantau percakapan ini). Bila ingin bantuan umum CS Admin, gunakan tombol **💬 Chat CS** yang melayang di pojok kanan bawah. Bila GPS tidak tersedia atau ingin mengirim titik lain, salin tautan dari Google Maps lalu tempel sebagai pesan. Tombol lokasi menyiapkan titik, tombol Kirim mengirimkannya. GPS bekerja pada localhost atau HTTPS. Peta Google membutuhkan internet.
4. **Keputusan admin.** Masuk sebagai admin di profil browser lain. Buka Pesanan → kode booking. Periksa rute dari Jombor melalui Maps, lalu isi jarak serta ongkir. Misalnya 5 km dan Rp20.000. Jarak sampai 2 km gratis. Jarak lebih dari 9 km membuka pilihan ambil sendiri atau batalkan. Booking ambil di rental langsung masuk tahap pembayaran.
5. **Pembayaran dan invoice.** Pelanggan membuka kembali detail pesanan, memilih DP Rp50.000 atau lunas, lalu mengisi referensi transfer/QRIS fiktif. Admin mencocokkan nominal dan memilih Pembayaran sesuai. Pelanggan dapat mencetak invoice atau menyimpannya sebagai PDF melalui dialog cetak browser.
6. **Serah terima dan kembali.** Untuk demo pada hari yang sama, pilih waktu mulai beberapa menit setelah waktu sekarang dan kembali sekurangnya 24 jam kemudian. Setelah jam mulai tiba, admin/petugas memeriksa identitas asli, menerima pelunasan dan mencatat serah terima. Status fisik motor menjadi sedang disewa. Pelanggan mengajukan pengembalian. Petugas memasukkan kondisi akhir dan menyelesaikan sewa. Invoice dan riwayat tetap tersimpan.
7. **Bukti penyelesaian masalah.** Cari kode booking dari dashboard, filter menurut status, buka ulang invoice, lalu lihat Data armada & laporan. Data armada menampilkan posisi fisik unit. Katalog menampilkan ketersediaan unit pada rentang jadwal yang dipilih.

## Cara membaca kode untuk presentasi
| Bagian | File atau folder | Fungsinya |
|---|---|---|
| Alamat halaman | routes/web.php | Memetakan URL ke controller dan membatasi halaman yang memerlukan login |
| Proses sewa | app/Http/Controllers/BookingController.php | Memvalidasi isian, menyimpan pesanan dan mengatur perpindahan status menurut peran |
| Harga dan stok | app/Services/Rental.php | Menghitung tarif dan mencari unit yang tidak bertabrakan |
| Pencarian semantik | app/Services/CatalogGraph.php, public/semantik/ontologi.ttl, public/semantik/pencarian.js | Membentuk graf RDF dari jadwal, menyimpan hubungan antarkelas di ontologi, dan memilih kartu motor memakai SPARQL |
| Chat & CS | app/Http/Controllers/ChatController.php, public/chat.js, public/cs-widget.js | Mengelola 3 ruang chat: Operasional (Petugas-Pelanggan + monitoring Admin), Internal Tim (Admin-Petugas), dan widget melayang CS Admin |
| Struktur database | database/migrations | Membuat tabel pengguna, tipe motor, unit, booking dan pesan |
| Data awal | database/seeders/DatabaseSeeder.php | Mengisi 35 unit dan tiga akun demo |
| Antarmuka | resources/views dan public/style.css | Menampilkan HTML semantik melalui Blade serta tata letak responsif |

## Cara kerja pencarian semantik

Laravel menghitung harga sewa dan jumlah unit yang tersedia untuk rentang waktu di layar. Kelas `CatalogGraph` menerbitkan hasil itu sebagai RDF dalam format JSON-LD di halaman katalog. Ontologi menyatakan bahwa motor matik merupakan salah satu jenis motor serta menghubungkan penawaran, model, dan merek. Browser menjalankan kueri SPARQL menggunakan Oxigraph 0.5.13 yang sudah disertakan di `public/semantik/oxigraph`. Fitur ini berjalan lewat server lokal tanpa instalasi Node.js. Tombol **Cek ketersediaan** mengambil data jadwal terbaru. Saat pemesan menyimpan formulir, Laravel memeriksa kembali ketersediaan di database.

## Cakupan terhadap Bab III pada 2 v3.pdf

| Kebutuhan | Yang bisa didemokan | Bagian rancangan yang masih perlu dikerjakan |
|---|---|---|
| FR-01, FR-02, FR-04 | Akun tiga peran, katalog RDF/SPARQL, cek jadwal per unit, transaksi booking dan penanganan pengiriman formulir berulang | — |
| FR-03 | Tampilan 35 unit dan tarif dari data awal | CRUD motor, tarif, pelanggan dan akun melalui dashboard |
| FR-05 | Validasi provinsi KTP yang diinput, NIK terenkripsi dan pemeriksaan asli saat serah terima | Unggah dokumen dan verifikasi berkas oleh admin |
| FR-06 | DP/lunas dengan referensi simulasi yang diperiksa admin, lalu terbit invoice | Midtrans Sandbox dan webhook pembayaran |
| FR-07 | Login petugas, serah terima, penerimaan kembali dan catatan kondisi unit | Penugasan per petugas dan unggah foto kondisi unit |
| FR-08, FR-09 | Tarif harian, akhir pekan dan paket, serta pembatalan saat pemeriksaan COD, pilihan pengambilan, atau sebelum pengajuan pembayaran | Denda otomatis, alur refund dan perpanjangan dengan validasi jadwal |
| FR-10 | Riwayat, filter status, ringkasan penerimaan dan invoice yang dapat dicetak | Ekspor laporan transaksi/pendapatan agregat PDF atau Excel |

Versi demonstrasi menggunakan Laravel 12 dan SQLite. NFR-03 pada PDF menyebut Laravel 11, MySQL, dan Midtrans Sandbox. Bukti pengujian demo lokal tidak mencakup uji beban dan pemulihan cadangan untuk penggunaan operasional.

## Acuan dan keputusan implementasi
- Identitas usaha dan konsep wisata sewa motor merujuk [blog Eksotis Jogja](https://eksotisjogja.blogspot.com/2017/09/rental-motor-jogja.html). Situs [AY Rental](https://ayrentalmotor.com/) menjadi rujukan penyajian katalog.
- Jumlah unit, jam operasional, ketentuan DP dan tabel tarif berasal dari **2 v3.pdf**. Saat nilai pada blog atau wireframe berbeda, aplikasi memakai tabel PDF. Foto ilustrasi produk diambil dari wireframe yang disertakan pengguna. Varian pada ilustrasi dapat berbeda dari tipe di tabel master. Kode unit seperti BEAT-01 merupakan kode inventaris contoh.
- Waktu menggunakan Asia/Jakarta. Sisa sebagian hari dibulatkan ke atas. Untuk durasi campuran, hitung paket 30 hari, lalu paket 7 hari, kemudian sisa hari sesuai hari dalam minggu. Jadwal yang berakhir tepat saat jadwal berikutnya dimulai tidak bertabrakan. Unit yang belum dikembalikan setelah lewat waktu akhir diblokir sampai pemeriksaan selesai.
- Verifikasi KTP pada formulir memakai provinsi domisili yang dipilih pelanggan; identitas asli diperiksa petugas. NIK disimpan terenkripsi. Pemesanan mandiri difokuskan pada pelanggan domestik. Pemeriksaan paspor/deposit WNA dilakukan melalui admin.
- Chat menggunakan polling 3,5 detik. Maps menampilkan koordinat yang dibagikan atau membuka tautan lokasi. Admin menentukan jarak rute dan ongkir. Pembayaran merupakan simulasi dengan verifikasi manual; tidak ada pemrosesan dana atau koneksi ke bank. Tagihan pada invoice mencakup sewa dan ongkir. Denda, ganti rugi dan refund diselesaikan manual.
- Cakupan wireframe dipusatkan pada katalog, akun, jadwal, booking, pembayaran, invoice, riwayat, chat, dashboard dan pengembalian dasar. Manajemen akun petugas, penugasan per petugas dan tanda tangan digital merupakan pengembangan lanjutan.
